﻿namespace CheckInterface
{
    partial class CheckInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbDigitalInputs = new System.Windows.Forms.GroupBox();
            this.EDigAuxiliar = new System.Windows.Forms.Label();
            this.E8Label = new System.Windows.Forms.Label();
            this.E7Label = new System.Windows.Forms.Label();
            this.E6Label = new System.Windows.Forms.Label();
            this.E5Label = new System.Windows.Forms.Label();
            this.E4Label = new System.Windows.Forms.Label();
            this.E3Label = new System.Windows.Forms.Label();
            this.E2Label = new System.Windows.Forms.Label();
            this.E1Label = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.gbDigitalOutputs = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.M4TrackBar = new System.Windows.Forms.TrackBar();
            this.M3TrackBar = new System.Windows.Forms.TrackBar();
            this.M2TrackBar = new System.Windows.Forms.TrackBar();
            this.M1TrackBar = new System.Windows.Forms.TrackBar();
            this.gbAnalogInputs = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.EYProgressBar = new System.Windows.Forms.ProgressBar();
            this.EXProgressBar = new System.Windows.Forms.ProgressBar();
            this.archivoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsIcono = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsBarraEstado = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerEntradas = new System.Windows.Forms.Timer(this.components);
            this.timerCheckInterface = new System.Windows.Forms.Timer(this.components);
            this.gbDigitalInputs.SuspendLayout();
            this.gbDigitalOutputs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.M4TrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.M3TrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.M2TrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.M1TrackBar)).BeginInit();
            this.gbAnalogInputs.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbDigitalInputs
            // 
            this.gbDigitalInputs.Controls.Add(this.EDigAuxiliar);
            this.gbDigitalInputs.Controls.Add(this.E8Label);
            this.gbDigitalInputs.Controls.Add(this.E7Label);
            this.gbDigitalInputs.Controls.Add(this.E6Label);
            this.gbDigitalInputs.Controls.Add(this.E5Label);
            this.gbDigitalInputs.Controls.Add(this.E4Label);
            this.gbDigitalInputs.Controls.Add(this.E3Label);
            this.gbDigitalInputs.Controls.Add(this.E2Label);
            this.gbDigitalInputs.Controls.Add(this.E1Label);
            this.gbDigitalInputs.Controls.Add(this.label12);
            this.gbDigitalInputs.Controls.Add(this.label11);
            this.gbDigitalInputs.Controls.Add(this.label10);
            this.gbDigitalInputs.Controls.Add(this.label9);
            this.gbDigitalInputs.Controls.Add(this.label8);
            this.gbDigitalInputs.Controls.Add(this.label7);
            this.gbDigitalInputs.Controls.Add(this.label6);
            this.gbDigitalInputs.Controls.Add(this.label5);
            this.gbDigitalInputs.Location = new System.Drawing.Point(12, 36);
            this.gbDigitalInputs.Name = "gbDigitalInputs";
            this.gbDigitalInputs.Size = new System.Drawing.Size(108, 278);
            this.gbDigitalInputs.TabIndex = 0;
            this.gbDigitalInputs.TabStop = false;
            this.gbDigitalInputs.Text = "Entradas Digitales";
            // 
            // EDigAuxiliar
            // 
            this.EDigAuxiliar.AutoSize = true;
            this.EDigAuxiliar.Location = new System.Drawing.Point(6, 262);
            this.EDigAuxiliar.Name = "EDigAuxiliar";
            this.EDigAuxiliar.Size = new System.Drawing.Size(66, 13);
            this.EDigAuxiliar.TabIndex = 20;
            this.EDigAuxiliar.Text = "inv aux label";
            this.EDigAuxiliar.Visible = false;
            // 
            // E8Label
            // 
            this.E8Label.AutoSize = true;
            this.E8Label.BackColor = System.Drawing.Color.Red;
            this.E8Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.E8Label.Location = new System.Drawing.Point(55, 240);
            this.E8Label.Name = "E8Label";
            this.E8Label.Size = new System.Drawing.Size(15, 15);
            this.E8Label.TabIndex = 15;
            this.E8Label.Text = "0";
            // 
            // E7Label
            // 
            this.E7Label.AutoSize = true;
            this.E7Label.BackColor = System.Drawing.Color.Red;
            this.E7Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.E7Label.Location = new System.Drawing.Point(55, 210);
            this.E7Label.Name = "E7Label";
            this.E7Label.Size = new System.Drawing.Size(15, 15);
            this.E7Label.TabIndex = 14;
            this.E7Label.Text = "0";
            // 
            // E6Label
            // 
            this.E6Label.AutoSize = true;
            this.E6Label.BackColor = System.Drawing.Color.Red;
            this.E6Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.E6Label.Location = new System.Drawing.Point(55, 180);
            this.E6Label.Name = "E6Label";
            this.E6Label.Size = new System.Drawing.Size(15, 15);
            this.E6Label.TabIndex = 13;
            this.E6Label.Text = "0";
            // 
            // E5Label
            // 
            this.E5Label.AutoSize = true;
            this.E5Label.BackColor = System.Drawing.Color.Red;
            this.E5Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.E5Label.Location = new System.Drawing.Point(55, 150);
            this.E5Label.Name = "E5Label";
            this.E5Label.Size = new System.Drawing.Size(15, 15);
            this.E5Label.TabIndex = 12;
            this.E5Label.Text = "0";
            // 
            // E4Label
            // 
            this.E4Label.AutoSize = true;
            this.E4Label.BackColor = System.Drawing.Color.Red;
            this.E4Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.E4Label.Location = new System.Drawing.Point(55, 120);
            this.E4Label.Name = "E4Label";
            this.E4Label.Size = new System.Drawing.Size(15, 15);
            this.E4Label.TabIndex = 11;
            this.E4Label.Text = "0";
            // 
            // E3Label
            // 
            this.E3Label.AutoSize = true;
            this.E3Label.BackColor = System.Drawing.Color.Red;
            this.E3Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.E3Label.Location = new System.Drawing.Point(55, 90);
            this.E3Label.Name = "E3Label";
            this.E3Label.Size = new System.Drawing.Size(15, 15);
            this.E3Label.TabIndex = 10;
            this.E3Label.Text = "0";
            // 
            // E2Label
            // 
            this.E2Label.AutoSize = true;
            this.E2Label.BackColor = System.Drawing.Color.Red;
            this.E2Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.E2Label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.E2Label.Location = new System.Drawing.Point(55, 60);
            this.E2Label.Name = "E2Label";
            this.E2Label.Size = new System.Drawing.Size(15, 15);
            this.E2Label.TabIndex = 9;
            this.E2Label.Text = "0";
            // 
            // E1Label
            // 
            this.E1Label.AutoSize = true;
            this.E1Label.BackColor = System.Drawing.Color.Red;
            this.E1Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.E1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E1Label.Location = new System.Drawing.Point(55, 30);
            this.E1Label.Name = "E1Label";
            this.E1Label.Size = new System.Drawing.Size(15, 15);
            this.E1Label.TabIndex = 8;
            this.E1Label.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(25, 240);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(23, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "E8:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(25, 210);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "E7:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 180);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "E6:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 150);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "E5:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 120);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "E4:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "E3:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "E2:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "E1:";
            // 
            // gbDigitalOutputs
            // 
            this.gbDigitalOutputs.Controls.Add(this.label26);
            this.gbDigitalOutputs.Controls.Add(this.label25);
            this.gbDigitalOutputs.Controls.Add(this.label24);
            this.gbDigitalOutputs.Controls.Add(this.label23);
            this.gbDigitalOutputs.Controls.Add(this.label22);
            this.gbDigitalOutputs.Controls.Add(this.label21);
            this.gbDigitalOutputs.Controls.Add(this.label20);
            this.gbDigitalOutputs.Controls.Add(this.label19);
            this.gbDigitalOutputs.Controls.Add(this.label18);
            this.gbDigitalOutputs.Controls.Add(this.label17);
            this.gbDigitalOutputs.Controls.Add(this.label16);
            this.gbDigitalOutputs.Controls.Add(this.label15);
            this.gbDigitalOutputs.Controls.Add(this.label4);
            this.gbDigitalOutputs.Controls.Add(this.label3);
            this.gbDigitalOutputs.Controls.Add(this.label2);
            this.gbDigitalOutputs.Controls.Add(this.label1);
            this.gbDigitalOutputs.Controls.Add(this.M4TrackBar);
            this.gbDigitalOutputs.Controls.Add(this.M3TrackBar);
            this.gbDigitalOutputs.Controls.Add(this.M2TrackBar);
            this.gbDigitalOutputs.Controls.Add(this.M1TrackBar);
            this.gbDigitalOutputs.Location = new System.Drawing.Point(126, 36);
            this.gbDigitalOutputs.Name = "gbDigitalOutputs";
            this.gbDigitalOutputs.Size = new System.Drawing.Size(148, 278);
            this.gbDigitalOutputs.TabIndex = 1;
            this.gbDigitalOutputs.TabStop = false;
            this.gbDigitalOutputs.Text = "Salidas Digitales";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(118, 210);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(21, 13);
            this.label26.TabIndex = 19;
            this.label26.Text = "cw";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(79, 210);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 13);
            this.label25.TabIndex = 18;
            this.label25.Text = "off";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(38, 210);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(27, 13);
            this.label24.TabIndex = 17;
            this.label24.Text = "ccw";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(118, 160);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(21, 13);
            this.label23.TabIndex = 16;
            this.label23.Text = "cw";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(79, 160);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(19, 13);
            this.label22.TabIndex = 15;
            this.label22.Text = "off";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(38, 160);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(27, 13);
            this.label21.TabIndex = 14;
            this.label21.Text = "ccw";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(118, 110);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(21, 13);
            this.label20.TabIndex = 13;
            this.label20.Text = "cw";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(79, 110);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 13);
            this.label19.TabIndex = 12;
            this.label19.Text = "off";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(38, 110);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(27, 13);
            this.label18.TabIndex = 11;
            this.label18.Text = "ccw";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(118, 60);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 13);
            this.label17.TabIndex = 10;
            this.label17.Text = "cw";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(79, 60);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(19, 13);
            this.label16.TabIndex = 9;
            this.label16.Text = "off";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(38, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(27, 13);
            this.label15.TabIndex = 8;
            this.label15.Text = "ccw";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "M4:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "M3:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "M2:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "M1:";
            // 
            // M4TrackBar
            // 
            this.M4TrackBar.Enabled = false;
            this.M4TrackBar.LargeChange = 1;
            this.M4TrackBar.Location = new System.Drawing.Point(37, 180);
            this.M4TrackBar.Maximum = 2;
            this.M4TrackBar.Name = "M4TrackBar";
            this.M4TrackBar.Size = new System.Drawing.Size(105, 42);
            this.M4TrackBar.TabIndex = 3;
            this.M4TrackBar.Value = 1;
            this.M4TrackBar.Scroll += new System.EventHandler(this.M4TrackBar_Scroll);
            // 
            // M3TrackBar
            // 
            this.M3TrackBar.Enabled = false;
            this.M3TrackBar.LargeChange = 1;
            this.M3TrackBar.Location = new System.Drawing.Point(37, 130);
            this.M3TrackBar.Maximum = 2;
            this.M3TrackBar.Name = "M3TrackBar";
            this.M3TrackBar.Size = new System.Drawing.Size(105, 42);
            this.M3TrackBar.TabIndex = 2;
            this.M3TrackBar.Value = 1;
            this.M3TrackBar.Scroll += new System.EventHandler(this.M3TrackBar_Scroll);
            // 
            // M2TrackBar
            // 
            this.M2TrackBar.Enabled = false;
            this.M2TrackBar.Location = new System.Drawing.Point(37, 80);
            this.M2TrackBar.Maximum = 2;
            this.M2TrackBar.Name = "M2TrackBar";
            this.M2TrackBar.Size = new System.Drawing.Size(105, 42);
            this.M2TrackBar.TabIndex = 1;
            this.M2TrackBar.Value = 1;
            this.M2TrackBar.Scroll += new System.EventHandler(this.M2TrackBar_Scroll);
            // 
            // M1TrackBar
            // 
            this.M1TrackBar.Enabled = false;
            this.M1TrackBar.LargeChange = 1;
            this.M1TrackBar.Location = new System.Drawing.Point(37, 30);
            this.M1TrackBar.Maximum = 2;
            this.M1TrackBar.Name = "M1TrackBar";
            this.M1TrackBar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.M1TrackBar.Size = new System.Drawing.Size(105, 42);
            this.M1TrackBar.TabIndex = 0;
            this.M1TrackBar.Value = 1;
            this.M1TrackBar.Scroll += new System.EventHandler(this.M1TrackBar_Scroll);
            // 
            // gbAnalogInputs
            // 
            this.gbAnalogInputs.Controls.Add(this.label32);
            this.gbAnalogInputs.Controls.Add(this.label31);
            this.gbAnalogInputs.Controls.Add(this.label30);
            this.gbAnalogInputs.Controls.Add(this.label29);
            this.gbAnalogInputs.Controls.Add(this.label28);
            this.gbAnalogInputs.Controls.Add(this.label27);
            this.gbAnalogInputs.Controls.Add(this.label14);
            this.gbAnalogInputs.Controls.Add(this.label13);
            this.gbAnalogInputs.Controls.Add(this.EYProgressBar);
            this.gbAnalogInputs.Controls.Add(this.EXProgressBar);
            this.gbAnalogInputs.Location = new System.Drawing.Point(12, 320);
            this.gbAnalogInputs.Name = "gbAnalogInputs";
            this.gbAnalogInputs.Size = new System.Drawing.Size(262, 92);
            this.gbAnalogInputs.TabIndex = 2;
            this.gbAnalogInputs.TabStop = false;
            this.gbAnalogInputs.Text = "Entradas Analógicas";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(228, 75);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(31, 13);
            this.label32.TabIndex = 9;
            this.label32.Text = "1024";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(149, 75);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(25, 13);
            this.label31.TabIndex = 8;
            this.label31.Text = "512";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(50, 75);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(13, 13);
            this.label30.TabIndex = 7;
            this.label30.Text = "0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(228, 45);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(31, 13);
            this.label29.TabIndex = 6;
            this.label29.Text = "1024";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(149, 45);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(25, 13);
            this.label28.TabIndex = 5;
            this.label28.Text = "512";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(50, 45);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(13, 13);
            this.label27.TabIndex = 4;
            this.label27.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(25, 60);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "EY:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(25, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 13);
            this.label13.TabIndex = 2;
            this.label13.Text = "EX:";
            // 
            // EYProgressBar
            // 
            this.EYProgressBar.Location = new System.Drawing.Point(55, 60);
            this.EYProgressBar.Maximum = 1024;
            this.EYProgressBar.Name = "EYProgressBar";
            this.EYProgressBar.Size = new System.Drawing.Size(198, 12);
            this.EYProgressBar.TabIndex = 1;
            // 
            // EXProgressBar
            // 
            this.EXProgressBar.Location = new System.Drawing.Point(55, 30);
            this.EXProgressBar.Maximum = 1024;
            this.EXProgressBar.Name = "EXProgressBar";
            this.EXProgressBar.Size = new System.Drawing.Size(198, 13);
            this.EXProgressBar.TabIndex = 0;
            // 
            // archivoMenuItem
            // 
            this.archivoMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salirMenuItem});
            this.archivoMenuItem.Name = "archivoMenuItem";
            this.archivoMenuItem.ShortcutKeyDisplayString = "";
            this.archivoMenuItem.Size = new System.Drawing.Size(55, 20);
            this.archivoMenuItem.Text = "&Archivo";
            // 
            // salirMenuItem
            // 
            this.salirMenuItem.Image = global::CheckInterface.Properties.Resources.gtk_quit;
            this.salirMenuItem.Name = "salirMenuItem";
            this.salirMenuItem.Size = new System.Drawing.Size(105, 22);
            this.salirMenuItem.Text = "Salir";
            this.salirMenuItem.Click += new System.EventHandler(this.salirMenuItem_Click);
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.configuraciónToolStripMenuItem});
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.editarToolStripMenuItem.Text = "&Editar";
            // 
            // configuraciónToolStripMenuItem
            // 
            this.configuraciónToolStripMenuItem.Image = global::CheckInterface.Properties.Resources.gtk_configure;
            this.configuraciónToolStripMenuItem.Name = "configuraciónToolStripMenuItem";
            this.configuraciónToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.configuraciónToolStripMenuItem.Text = "&Configuración...";
            this.configuraciónToolStripMenuItem.Click += new System.EventHandler(this.configuraciónToolStripMenuItem_Click);
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acercaDeToolStripMenuItem});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.ayudaToolStripMenuItem.Text = "Ay&uda";
            // 
            // acercaDeToolStripMenuItem
            // 
            this.acercaDeToolStripMenuItem.Image = global::CheckInterface.Properties.Resources.gtk_about;
            this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.acercaDeToolStripMenuItem.Text = "Acerca de...";
            this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.acercaDeToolStripMenuItem_Click);
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoMenuItem,
            this.editarToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip.Size = new System.Drawing.Size(287, 24);
            this.menuStrip.TabIndex = 3;
            this.menuStrip.Text = "menuStrip1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsIcono,
            this.tsBarraEstado});
            this.statusStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.statusStrip1.Location = new System.Drawing.Point(0, 420);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(287, 21);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsIcono
            // 
            this.tsIcono.Image = global::CheckInterface.Properties.Resources.gtk_no;
            this.tsIcono.Name = "tsIcono";
            this.tsIcono.Size = new System.Drawing.Size(16, 16);
            // 
            // tsBarraEstado
            // 
            this.tsBarraEstado.BackColor = System.Drawing.SystemColors.Control;
            this.tsBarraEstado.Name = "tsBarraEstado";
            this.tsBarraEstado.Size = new System.Drawing.Size(162, 13);
            this.tsBarraEstado.Text = "La interfaz no está conectada...";
            // 
            // timerEntradas
            // 
            this.timerEntradas.Interval = 10;
            this.timerEntradas.Tick += new System.EventHandler(this.timerEntradas_Tick);
            // 
            // timerCheckInterface
            // 
            this.timerCheckInterface.Enabled = true;
            this.timerCheckInterface.Interval = 500;
            this.timerCheckInterface.Tick += new System.EventHandler(this.timerCheckInterface_Tick);
            // 
            // CheckInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 441);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.gbAnalogInputs);
            this.Controls.Add(this.gbDigitalOutputs);
            this.Controls.Add(this.gbDigitalInputs);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "CheckInterface";
            this.Text = "Check Interface";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbDigitalInputs.ResumeLayout(false);
            this.gbDigitalInputs.PerformLayout();
            this.gbDigitalOutputs.ResumeLayout(false);
            this.gbDigitalOutputs.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.M4TrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.M3TrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.M2TrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.M1TrackBar)).EndInit();
            this.gbAnalogInputs.ResumeLayout(false);
            this.gbAnalogInputs.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbDigitalInputs;
        private System.Windows.Forms.GroupBox gbDigitalOutputs;
        private System.Windows.Forms.GroupBox gbAnalogInputs;
        private System.Windows.Forms.TrackBar M2TrackBar;
        private System.Windows.Forms.TrackBar M1TrackBar;
        private System.Windows.Forms.ToolStripMenuItem archivoMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar M4TrackBar;
        private System.Windows.Forms.TrackBar M3TrackBar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label E1Label;
        private System.Windows.Forms.Label E8Label;
        private System.Windows.Forms.Label E7Label;
        private System.Windows.Forms.Label E6Label;
        private System.Windows.Forms.Label E5Label;
        private System.Windows.Forms.Label E4Label;
        private System.Windows.Forms.Label E3Label;
        private System.Windows.Forms.Label E2Label;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsBarraEstado;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ProgressBar EYProgressBar;
        private System.Windows.Forms.ProgressBar EXProgressBar;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
        private System.Windows.Forms.Label EDigAuxiliar;
        private System.Windows.Forms.Timer timerEntradas;
        private System.Windows.Forms.Timer timerCheckInterface;
        private System.Windows.Forms.ToolStripStatusLabel tsIcono;
    }
}

